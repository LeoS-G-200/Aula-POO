function y=degrau(x)
% y=degrau(x), determines the step function

y= (x>0) + 0.5*(x==0);
